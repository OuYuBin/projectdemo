package httpclientlogin.jushdto;

public class NotificationDto {
	private String alert;

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

}
