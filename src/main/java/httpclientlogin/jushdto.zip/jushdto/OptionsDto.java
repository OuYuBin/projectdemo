package httpclientlogin.jushdto;

public class OptionsDto {
	private int time_to_live;

	public int getTime_to_live() {
		return time_to_live;
	}

	public void setTime_to_live(int time_to_live) {
		this.time_to_live = time_to_live;
	}

}
