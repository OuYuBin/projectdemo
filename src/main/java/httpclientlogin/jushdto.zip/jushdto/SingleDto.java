package httpclientlogin.jushdto;

public class SingleDto {
	private String time;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
