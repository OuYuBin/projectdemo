package httpclientlogin.jushdto;

public class TriggerDto {
	private SingleDto single;

	public SingleDto getSingle() {
		return single;
	}

	public void setSingle(SingleDto single) {
		this.single = single;
	}

}
